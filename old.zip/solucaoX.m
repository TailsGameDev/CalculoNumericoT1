function [x NOP] = solucaoX(n,U,C,NOP)
    x(n) = C(n);
    for i=n-1: -1: 1 %SETAR PASSO EM -1!!
        %U(i,i+1:n)
        x(i) = C(i) - sum(U(i,i+1:n).*x(i+1:n)); %botei .* no *
        NOP+= 1+n-i; % acho que é 1 + n-i-1, mas se tirasse um, incluiria o i+1, de repente eh isso mesmo
    end
    x = transpose(x);
end