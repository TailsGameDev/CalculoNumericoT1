function x = fGaussSeidelRelax(n, t, r, d, b, x0, tol, relax)
    x = x0;
    k = 0;
    stop = 10;
    comp_relax = (1-relax);
    op = 1; %numero de operacoes
    while stop > tol && k < 500
        i=1;
        %x(i) = ( b(i) - d(i)*x(i+1) )/r(i);
        x(i) = comp_relax*x0(i) + relax*( b(i) - d(i)*x(i+1) )/r(i);
        op +=6;
        for i =2 : n-1
            %x(i) = ( 1 - t(i) - d(i) )/r(i);
            x(i) = comp_relax*x0(i) + relax *(b(i) - (t(i)*x(i-1)+d(i)*x(i+1)))/r(i);
            op+=8;
        end
        
        i = n;
            x(i) = comp_relax*x0(i) + relax *( b(i) - t(i)*x(i-1) )/r(i);
            op+=6;
        stop = max(abs(x .-x0)); op+=n;
        
        x0 = x;
        k++;
    end
    k
    op %no LU precisa mandar os ops de uma funcao pra outra
end