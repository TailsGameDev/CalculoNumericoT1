function [C NOP] = solucaoC(n,L,B,NOP)

    C(1) = B(1)/L(1,1); NOP++;
    
    for i=2:n
        %COLOCANDO .* INDICA PRODUTO VETORIAL.
        %DIFERENTE DE PRODUTO MATRICIAL. (X1,X2) .* (Y1,Y2) = (X1*Y1) + (X2,Y2) ALGO ASSIM
        C(i) = (B(i) - sum(L(i,1:i-1).*C(1:i-1)))/L(i,i); NOP+=2 +i-1;
    end
    
    %precisamos tratar sistemas indeterminados e impossiveis
end