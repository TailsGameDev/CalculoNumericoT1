format long

% terminar tridiag

%armazenamento na forma de vetores

n=8

for i = 1
    r(i) = 1; d(i) = 1; B(i)=1.5
end

for i = 2 : n/2
    t(i) = 1; r(i) = 4; d(i) = 1; B(i) = 1;
end

for i = n/2 + 1 : n-1
    t(i) = 1; r(i) = 5; d(i) = 1; B(i) = 2;
end

for i = n
    t(i)=1; r(i) = 1; B(i) =3; 
end

%t
%r
%d

%x = solucaoLUCRout(A,B,NOP)

xi(1:n) = 0;
tol = 1e-4;
relax = 1;

x = fGaussSeidelRelax(n, t, r, d, B, xi, tol, relax)

xe = fGaussSeidelRelax(n, t, r, d, B, xi, tol*tol, relax)

erroMax = max(abs(x .- xe))

%40 * 41 * 8 = bytes gastos na matriz quadrada
%na tridiag em vetores, 4*n*8

