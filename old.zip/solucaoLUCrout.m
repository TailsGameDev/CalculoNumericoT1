function x = solucaoLUCrout(A,B)
    %n eh o tamanho da matriz
    n = length(A);
    [L U B NOP] = fLUCrout(n,A,B);
    teste = L*U - A;
    
    %Ax = B
    %[LU]x = B
    %L[Ux] = B
    %LC = B
    %LC = B -> C
    
    %Ux = C
    
    [C NOP] = solucaoC(n,L,B,NOP);
    [x NOP] = solucaoX(n,U,C, NOP);
    %C = solucaoC(L,B);
    %x = solucaoX(U,C)
end